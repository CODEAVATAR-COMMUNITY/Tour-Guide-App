package com.example.android.ash_udacity;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import java.util.ArrayList;

public class WaterparkFragment extends Fragment {
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.word_list, container, false);

        // Create a list of word
        final ArrayList<words> word = new ArrayList<words>();
        word.add(new words(R.string.water_one, R.string.water_one_address,R.string.water_one_phone,R.string.water_one_time,
                R.drawable.sunshine));
        word.add(new words(R.string.water_two, R.string.water_two_address,R.string.water_one_phone,R.string.water_one_time,
                R.drawable.appughar));
        word.add(new words(R.string.water_three, R.string.water_three_address,R.string.water_three_phone,R.string.water_three_time,
                R.drawable.angel));
        word.add(new words(R.string.water_four, R.string.water_four_address,R.string.water_four_phone,R.string.water_four_time,
                R.drawable.maujmahal));
        word.add(new words(R.string.water_five, R.string.water_five_address,R.string.water_five_phone,R.string.water_five_time,
                R.drawable.fungaon));
        word.add(new words(R.string.water_six, R.string.water_six_address,R.string.water_six_phone,R.string.water_six_time,
                R.drawable.sunrise));
        word.add(new words(R.string.water_seven, R.string.water_seven_address,R.string.water_seven_phone,R.string.water_seven_time,
                R.drawable.hotelapano));
        word.add(new words(R.string.water_eight, R.string.water_eight_address,R.string.water_eight_phone,R.string.water_eight_time,
                R.drawable.birlacity));
        word.add(new words(R.string.water_nine, R.string.water_nine_address,R.string.water_nine_phone,R.string.water_nine_time,
                R.drawable.pinkpearl));
        word.add(new words(R.string.water_ten, R.string.water_ten_address,R.string.water_ten_phone,R.string.water_ten_time,
                R.drawable.swapanlok));

        WordAdapter adapter = new WordAdapter(getActivity(), word, R.color.Category_waterpark);

        ListView listView = (ListView) rootView.findViewById(R.id.list);
        listView.setAdapter(adapter);
        return rootView;
    }
}
