package com.example.android.ash_udacity;

public class words {
    private int mplacename;
    private int mplaceaddress;
    private int mmobileno;
    private int mtiming;
    private int mimageresourceid;

    public words(int placeName, int placeAdress, int mobileNo, int timing) {
    mplacename=placeName;
    mplaceaddress=placeAdress;
    mmobileno=mobileNo;
    mtiming=timing;
    }
public words(int placeName, int placeAdress, int mobileNo, int timing, int ImageResoureId)
{
    mplacename=placeName;
    mplaceaddress=placeAdress;
    mmobileno=mobileNo;
    mtiming=timing;
    mimageresourceid=ImageResoureId;
}

    public int getMplacename() {
        return mplacename;
    }

    public int getMplaceaddress() {
        return mplaceaddress;
    }

    public int getMmobileno() {
        return mmobileno;
    }

    public int getMtiming() {
        return mtiming;
    }

    public int getMimageresourceid() {
        return mimageresourceid;
    }
}
