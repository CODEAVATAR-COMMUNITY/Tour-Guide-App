package com.example.android.ash_udacity;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import java.util.ArrayList;

public class TemplesFragment extends Fragment {
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.word_list, container, false);

        // Create a list of words
        final ArrayList<words> word = new ArrayList<words>();
        word.add(new words(R.string.temp_one, R.string.temp_one_address, R.string.temp_one_phone, R.string.temp_one_time, R.drawable.motidungri));
        word.add(new words(R.string.temp_two, R.string.temp_two_address, R.string.temp_one_phone, R.string.temp_one_time, R.drawable.birlamandir));
        word.add(new words(R.string.temp_three, R.string.temp_three_address, R.string.temp_three_phone, R.string.temp_three_time, R.drawable.govinddevji));
        word.add(new words(R.string.temp_four, R.string.temp_four_address, R.string.temp_four_phone, R.string.temp_four_time, R.drawable.akshardham));
        word.add(new words(R.string.temp_five, R.string.temp_five_address, R.string.temp_five_phone, R.string.temp_five_time, R.drawable.garhganesh));
        word.add(new words(R.string.temp_six, R.string.temp_six_address, R.string.temp_six_phone, R.string.temp_six_time, R.drawable.iskcon));
        word.add(new words(R.string.temp_seven, R.string.temp_seven_address, R.string.temp_seven_phone, R.string.temp_seven_time, R.drawable.jainmandir));
        word.add(new words(R.string.temp_eight, R.string.temp_eight_address, R.string.temp_eight_phone, R.string.temp_eight_time, R.drawable.kalehanumanjitemple));
        word.add(new words(R.string.temp_nine, R.string.temp_nine_address, R.string.temp_nine_phone, R.string.temp_nine_time, R.drawable.matashiladevi));
        word.add(new words(R.string.temp_ten, R.string.temp_ten_address, R.string.temp_ten_phone, R.string.temp_ten_time, R.drawable.tarkeshwarmandir));

        WordAdapter adapter = new WordAdapter(getActivity(), word, R.color.Category_temple);

        ListView listView = (ListView) rootView.findViewById(R.id.list);
        listView.setAdapter(adapter);
        return rootView;
    }
}
