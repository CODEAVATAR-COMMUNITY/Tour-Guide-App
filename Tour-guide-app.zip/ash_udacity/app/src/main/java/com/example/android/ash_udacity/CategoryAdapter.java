package com.example.android.ash_udacity;

import android.content.Context;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

public class CategoryAdapter extends FragmentPagerAdapter {
private Context mcontext;
    public CategoryAdapter(Context context ,FragmentManager fm) {
        super(fm);
        mcontext=context;
    }

    @Override
    public Fragment getItem(int position) {
        if(position==0)
        {
            return new TemplesFragment();
        }
        else if(position==1)
        {
            return new HistoricalPlaceFragment();
        }
        else if(position==2)
        {
            return new WaterparkFragment();
        }
        else
        {
            return new HotelFragment();
        }

    }

    @Override
    public int getCount() {
        return 4;
    }
    @Override
    public CharSequence getPageTitle(int position) {
        if (position == 0) {
            return mcontext.getString(R.string.Category_temple);
        } else if (position == 1) {
            return mcontext.getString(R.string.Category_historical_place);
        } else if (position == 2) {
            return mcontext.getString(R.string.Category_waterpark);
        } else {
            return mcontext.getString(R.string.Cateogory_hotels);
        }

    }
}
